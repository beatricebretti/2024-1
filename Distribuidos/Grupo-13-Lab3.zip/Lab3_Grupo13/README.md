# Laboratorio 3 - Grupo 13

## Integrantes
- Beatrice Valdes - 201941556-5
- Tomas Garreton - 201823565-2

# Ejecución 
- `make all`: compila el todo y lo ejecuta.
- `make build`: Compila localmente.
- `make docker-build`: Construye las imágenes Docker.
- `make run`: Ejecuta el proyecto.
- `make clean`: limpia binarios compilados y detiene los contenedores Docker.
